#-*- coding: utf-8 -*-
import xlrd

from datetime import date,datetime

def read_excel():
    ExcelFile=xlrd.open_workbook(r'/home/castiel/20190610.xlsx')
    print(ExcelFile.sheet_names()[0])

read_excel()
