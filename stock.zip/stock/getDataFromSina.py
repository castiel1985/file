import util
import time

for i in range( 1, 9999 ):    
    
    print( time.strftime('%H:%M',time.localtime(time.time())) )
    
    url = util.sinaStockUrl( pageNum = i )    
    stockData = util.sinaStockData( url = url )
    if( stockData == 'null' ):
        break        
    effect_rows = util.dbStore( str_stocks = stockData )
    time.sleep(3)
    
print( 'finished.' )
