import tushare as ts

d = ts.get_tick_data('600831', date='2019-06-11', src='tt')

d.head(10)
